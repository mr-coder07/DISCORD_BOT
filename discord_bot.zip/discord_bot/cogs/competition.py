import discord
from discord.ext import commands
import datetime
import asyncio
from collections import defaultdict
import json
import os
from typing import Dict, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CompetitionConfig:
    """Configuration class for competition settings"""
    def __init__(self):
        self.POINTS_PER_QUESTION = 5
        self.TIME_LIMIT_MINUTES = 1
        self.TOTAL_QUESTIONS = 3
        self.POINT_LOSS_PER_MINUTE = 1
        self.QUESTION_TIMEOUT_MINUTES = 0.5
        self.SAVE_FILE = "competition_data.json"
        self.QUESTIONS = {
            1: {"question": "What is the capital of France?", "answers": ["paris"]},
            2: {"question": "What is 2 + 2?", "answers": ["4"]},
            3: {"question": "Who wrote 'Romeo and Juliet'?", "answers": ["shakespeare"]}
        }


class CompetitionState:
    """Class to manage competition state"""
    def __init__(self):
        self.start_time: datetime.datetime = datetime.datetime.now()
        self.is_active: bool = True
        self.current_question: int = 1
        self.participants: Dict[int, Dict] = {}
        self.timeout_task: Optional[asyncio.Task] = None

class Competition(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = CompetitionConfig()
        self.active_competitions: Dict[discord.TextChannel, CompetitionState] = {}
        self.leaderboard = defaultdict(int)
        self.question_timestamps: Dict[int, datetime.datetime] = {}
        self.load_data()

    def load_data(self):
        """Load saved leaderboard data with error handling"""
        try:
            if os.path.exists(self.config.SAVE_FILE):
                with open(self.config.SAVE_FILE, 'r') as f:
                    data = json.load(f)
                    self.leaderboard = defaultdict(int, data.get('leaderboard', {}))
                logger.info("Leaderboard data loaded successfully")
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            self.leaderboard = defaultdict(int)

    async def save_data(self):
        """Save leaderboard data to file asynchronously"""
        try:
            async with asyncio.Lock():
                with open(self.config.SAVE_FILE, 'w') as f:
                    json.dump({'leaderboard': dict(self.leaderboard)}, f)
            logger.info("Leaderboard data saved successfully")
        except Exception as e:
            logger.error(f"Error saving data: {e}")

    @commands.command(name='startcomp')
    @commands.has_permissions(manage_messages=True)
    @commands.cooldown(1, 30, commands.BucketType.channel)
    async def start_competition(self, ctx):
        if not ctx.author.guild_permissions.manage_messages:
            await ctx.send("❌ You need the Manage Messages permission to start a competition.")
            return
        """Start a new competition with improved error handling"""
        try:
            if ctx.channel.id in [c.id for c in self.active_competitions.keys()]:
                await ctx.send("❌ A competition is already running in this channel!")
                return

            # Create new competition state
            comp_state = CompetitionState()
            self.active_competitions[ctx.channel] = comp_state

            # Create and send competition info embed
            embed = self.create_competition_info_embed()
            await ctx.send(embed=embed)

            # Start the competition with the first question
            await self.ask_next_question(ctx.channel)

        except Exception as e:
            logger.error(f"Error starting competition: {e}")
            await ctx.send("❌ An error occurred while starting the competition.")
            # Clean up if competition failed to start
            if ctx.channel in self.active_competitions:
                del self.active_competitions[ctx.channel]

    def create_competition_info_embed(self) -> discord.Embed:
        """Create competition information embed"""
        embed = discord.Embed(
            title="🎮 New Competition Started!",
            color=discord.Color.green(),
            timestamp=datetime.datetime.now()
        )
        embed.add_field(name="Total Questions", value=str(self.config.TOTAL_QUESTIONS), inline=True)
        embed.add_field(name="Points per Question", value=str(self.config.POINTS_PER_QUESTION), inline=True)
        embed.add_field(name="Time Limit (minutes)", value=str(self.config.TIME_LIMIT_MINUTES), inline=True)
        embed.add_field(name="Point Loss per Minute", value=str(self.config.POINT_LOSS_PER_MINUTE), inline=True)
        embed.set_footer(text="Answer the questions as fast as you can!")
        return embed

    async def ask_next_question(self, channel: discord.TextChannel):
        """Ask the next question with improved timeout handling"""
        if channel not in self.active_competitions:
            return

        comp_state = self.active_competitions[channel]
        current_question = comp_state.current_question

        if current_question > self.config.TOTAL_QUESTIONS:
            await self.end_competition(channel)
            return

        # Cancel existing timeout task if any
        if comp_state.timeout_task and not comp_state.timeout_task.done():
            comp_state.timeout_task.cancel()

        # Create and send question embed
        question_data = self.config.QUESTIONS[current_question]
        embed = self.create_question_embed(current_question, question_data["question"])
        await channel.send(embed=embed)

        # Set question timestamp
        self.question_timestamps[current_question] = datetime.datetime.now()

        # Create new timeout task
        comp_state.timeout_task = asyncio.create_task(
            self.handle_question_timeout(channel, current_question)
        )

    async def handle_question_timeout(self, channel: discord.TextChannel, question_number: int):
        """Handle question timeout"""
        await asyncio.sleep(self.config.QUESTION_TIMEOUT_MINUTES * 60)
        if channel in self.active_competitions:
            comp_state = self.active_competitions[channel]
            if comp_state.current_question == question_number:
                await channel.send(f"⏰ Time's up for question {question_number}!")
                comp_state.current_question += 1
                await self.ask_next_question(channel)

    def create_question_embed(self, question_number: int, question: str) -> discord.Embed:
        """Create question embed"""
        return discord.Embed(
            title=f"❓ Question {question_number}",
            description=question,
            color=discord.Color.blue(),
            timestamp=datetime.datetime.now()
        )

    @commands.command(name='lb')
    async def show_leaderboard(self, ctx):
        """Command to display the leaderboard"""
        if not self.leaderboard:
            await ctx.send("📊 The leaderboard is currently empty!")
            return

        leaderboard_sorted = sorted(self.leaderboard.items(), key=lambda x: x[1], reverse=True)
        embed = discord.Embed(title="🏆 Leaderboard", color=discord.Color.gold(), timestamp=datetime.datetime.now())

        for i, (user, score) in enumerate(leaderboard_sorted, start=1):
            embed.add_field(name=f"{i}. {user}", value=f"Points: {score}", inline=False)

        await ctx.send(embed=embed)

    @commands.command(name='answer')
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def submit_answer(self, ctx, question_number: int, *, answer: str):
        """Submit an answer with improved validation and scoring"""
        try:
            # Validate competition state
            if not await self.validate_answer_submission(ctx, question_number):
                return

            comp_state = self.active_competitions[ctx.channel]
            
            # Process answer and calculate points
            points = await self.process_answer(ctx, question_number, answer)
            if points is None:
                return

            # Update leaderboard and save
            self.leaderboard[ctx.author.name] += points
            await self.save_data()

            # Send results
            await self.send_answer_results(ctx, question_number, points)

            # Move to next question
            comp_state.current_question += 1
            await self.ask_next_question(ctx.channel)

        except Exception as e:
            logger.error(f"Error processing answer: {e}")
            await ctx.send("❌ An error occurred while processing your answer.")

    async def validate_answer_submission(self, ctx, question_number: int) -> bool:
        """Validate answer submission conditions"""
        if not 1 <= question_number <= self.config.TOTAL_QUESTIONS:
            await ctx.send(f"❌ Question number must be between 1 and {self.config.TOTAL_QUESTIONS}")
            return False

        if ctx.channel not in self.active_competitions:
            await ctx.send("❌ No active competition in this channel!")
            return False

        comp_state = self.active_competitions[ctx.channel]
        if question_number != comp_state.current_question:
            await ctx.send(f"❌ This is not the current question. Please answer question {comp_state.current_question}.")
            return False

        return True

    async def process_answer(self, ctx, question_number: int, answer: str) -> Optional[int]:
        """Process answer and calculate points"""
        correct_answers = [a.lower() for a in self.config.QUESTIONS[question_number]["answers"]]
        if answer.lower().strip() not in correct_answers:
            await ctx.send("❌ Incorrect answer. Try again!")
            return None

        time_taken = datetime.datetime.now() - self.question_timestamps[question_number]
        minutes_taken = time_taken.total_seconds() / 60

        points = self.config.POINTS_PER_QUESTION
        points_lost = min(int(minutes_taken) * self.config.POINT_LOSS_PER_MINUTE, points)
        return max(0, points - points_lost)

    async def send_answer_results(self, ctx, question_number: int, points: int):
        """Send answer results to user"""
        embed = discord.Embed(
            title="✅ Correct Answer!",
            color=discord.Color.green(),
            timestamp=datetime.datetime.now()
        )
        embed.add_field(name="Question", value=self.config.QUESTIONS[question_number]["question"])
        embed.add_field(name="Points Earned", value=str(points))
        
        try:
            await ctx.author.send(embed=embed)
        except discord.Forbidden:
            await ctx.send("❌ I couldn't DM you the result. Make sure your DMs are open!")

        await self.show_leaderboard(ctx)

    @commands.command(name='endcomp')
    @commands.has_permissions(manage_messages=True)
    async def end_competition(self, ctx):
        """End competition with improved cleanup"""
        try:
            if isinstance(ctx, discord.TextChannel):
                channel = ctx
            else:
                channel = ctx.channel

            if channel not in self.active_competitions:
                if not isinstance(ctx, discord.TextChannel):
                    await ctx.send("❌ No active competition to end!")
                return

            comp_state = self.active_competitions[channel]
            
            # Cancel timeout task if exists
            if comp_state.timeout_task and not comp_state.timeout_task.done():
                comp_state.timeout_task.cancel()

            # Show final results
            await self.show_final_results(channel)

            # Cleanup
            del self.active_competitions[channel]
            await channel.send(embed=discord.Embed(
                title="🎉 Competition Ended!",
                description="Thanks for participating!",
                color=discord.Color.green(),
                timestamp=datetime.datetime.now()
            ))

        except Exception as e:
            logger.error(f"Error ending competition: {e}")
            if not isinstance(ctx, discord.TextChannel):
                await ctx.send("❌ An error occurred while ending the competition.")

    async def show_final_results(self, channel: discord.TextChannel):
        """Show final competition results"""
        if self.leaderboard:
            await self.show_leaderboard(channel)
        else:
            await channel.send("📊 No scores recorded for this competition!")

def setup(bot):
    bot.add_cog(Competition(bot))